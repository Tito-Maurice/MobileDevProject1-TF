//
//  ViewController.swift
//  MobileDevProject1
//
//  Created by Tito-Maurice Fynn on 1/21/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

